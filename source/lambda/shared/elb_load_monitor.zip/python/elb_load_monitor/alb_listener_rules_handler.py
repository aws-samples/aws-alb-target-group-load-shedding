from boto3 import client
from elb_load_monitor.alb_alarm_messages import ALBAlarmAction
from elb_load_monitor.alb_alarm_messages import ALBAlarmEvent
from elb_load_monitor.alb_alarm_messages import ALBAlarmStatusMessage
from elb_load_monitor.alb_alarm_messages import CWAlarmState
from elb_load_monitor.elb_listener_rule import ELBListenerRule

import json
import logging


logger = logging.getLogger()


class ALBListenerRulesHandler:

    def __init__(
            self, elbv2_client: client, load_balancer_arn: str, elb_listener_arn: str, target_group_arn: str,
            elb_shed_percent: int, sqs_queue_delay: int
    ) -> None:
        self.load_balancer_arn = load_balancer_arn
        self.elb_listener_arn = elb_listener_arn
        self.target_group_arn = target_group_arn
        self.elb_shed_percent = elb_shed_percent
        self.sqs_queue_delay = sqs_queue_delay

        describe_rules_response = elbv2_client.describe_rules(
            ListenerArn=elb_listener_arn
        )

        logger.info('Response' + json.dumps(describe_rules_response))

        elb_rules_entries = describe_rules_response['Rules']
        self.elb_rules = []

        for elb_rule_entry in elb_rules_entries:
            if elb_rule_entry['IsDefault']:
                # skip the default rule
                continue

            action_type = elb_rule_entry['Actions'][0]['Type']
            if action_type != 'forward':
                # skip redirect and fixed response actions
                continue

            elb_listener_rule = ELBListenerRule(elb_rule_entry['RuleArn'])
            self.elb_rules.append(elb_listener_rule)

            for target_group in elb_rule_entry['Actions'][0]['ForwardConfig']['TargetGroups']:
                elb_listener_rule.add_forward_config(
                    target_group['TargetGroupArn'], target_group['Weight'])

        return

    def handle_alarm(
            self, elbv2_client: client, sqs_client: client, sqs_queue_url: str, alb_alarm_event: ALBAlarmEvent
    ) -> ALBAlarmAction:

        alarm_action = ALBAlarmAction.NONE

        if alb_alarm_event.cw_alarm_state == CWAlarmState.ALARM:
            alarm_action = ALBAlarmAction.SHED

            self.shed(elbv2_client, self.target_group_arn,
                      self.elb_shed_percent)
        elif alb_alarm_event.cw_alarm_state == CWAlarmState.OK:
            alarm_action = ALBAlarmAction.RESTORE

        if alarm_action != ALBAlarmAction.NONE:
            self.send_sqs_notification(
                sqs_client, sqs_queue_url, alb_alarm_event.alarm_arn, alb_alarm_event.alarm_name, alarm_action)

        return alarm_action

    def handle_alarm_status_message(
            self, cw_client: client, elbv2_client: client, sqs_client: client,
            alb_alarm_status_message: ALBAlarmStatusMessage
    ) -> ALBAlarmAction:

        alarm_response = cw_client.describe_alarms(
            AlarmNames=[
                alb_alarm_status_message.cw_alarm_name
            ]
        )

        cw_alarm_state = CWAlarmState[alarm_response['MetricAlarms']
                                      [0]['StateValue']]

        previous_alb_alarm_action = alb_alarm_status_message.alb_alarm_action

        new_alarm_action = ALBAlarmAction.NONE

        if cw_alarm_state == CWAlarmState.ALARM:
            # if current alarm state is ALARM, shed if previous alarm action was SHED
            # otherwise, set the state to SHED and send the message. This will trigger
            # shedding in the next interval
            if previous_alb_alarm_action == ALBAlarmAction.SHED:
                self.shed(
                    elbv2_client, alb_alarm_status_message.target_group_arn,
                    alb_alarm_status_message.elb_shed_percent)

            new_alarm_action = ALBAlarmAction.SHED

            # todo do we need to worry about "over shedding"?

        elif cw_alarm_state == CWAlarmState.OK:
            # if current CWAlarm state is OK, restore if the previous alarm action was RESTORE
            # otherwise, check if we have available capacity to restore and set the state to RESTORE.
            # This will trigger restore  in the next interval
            if previous_alb_alarm_action == ALBAlarmAction.RESTORE:
                self.restore(
                    elbv2_client, alb_alarm_status_message.target_group_arn,
                    alb_alarm_status_message.elb_shed_percent)

            if self.is_restorable(alb_alarm_status_message.target_group_arn):
                # if there is more load available, continue to restore
                new_alarm_action = ALBAlarmAction.RESTORE

        elif cw_alarm_state == CWAlarmState.INSUFFICIENT_DATA:
            # if we have insufficient data in the alarm, queue and re-evaulate in
            # the next interval
            new_alarm_action = previous_alb_alarm_action

        if new_alarm_action != ALBAlarmAction.NONE:
            self.send_sqs_notification(
                sqs_client, alb_alarm_status_message.sqs_queue_url, alb_alarm_status_message.cw_alarm_arn,
                alb_alarm_status_message.cw_alarm_name, new_alarm_action)

        return new_alarm_action

    def send_sqs_notification(
            self, sqs_client: client, sqs_queue_url: str, cw_alarm_arn: str, cw_alarm_name: str,
            alarm_action: ALBAlarmAction
    ) -> None:
        alb_alarm_status_message = ALBAlarmStatusMessage(
            cw_alarm_arn=cw_alarm_arn, cw_alarm_name=cw_alarm_name,
            load_balancer_arn=self.load_balancer_arn, elb_listener_arn=self.elb_listener_arn,
            target_group_arn=self.target_group_arn, sqs_queue_url=sqs_queue_url,
            sqs_queue_delay=self.sqs_queue_delay, elb_shed_percent=self.elb_shed_percent,
            alb_alarm_action=alarm_action)

        # if we took an action, we want to re-evaluate the decision in 60s
        sqs_client.send_message(
            QueueUrl=sqs_queue_url,
            DelaySeconds=self.sqs_queue_delay,
            MessageBody=json.dumps(alb_alarm_status_message.to_json()),
        )

    def get_elb_rules(self) -> list:
        return self.elb_rules

    def is_restorable(self, source_group_arn: str) -> bool:
        for elb_rule in self.elb_rules:
            if elb_rule.is_restorable(source_group_arn):
                return True

        return False

    def restore(self, elbv2_client: client, source_group_arn: str, weight: int) -> None:
        for elb_rule in self.elb_rules:
            elb_rule.restore(source_group_arn, weight)

        for elb_rule in self.elb_rules:
            elb_rule.save(elbv2_client)

        return

    def shed(self, elbv2_client: client, source_group_arn: str, weight: int) -> None:
        for elb_rule in self.elb_rules:
            elb_rule.shed(source_group_arn, weight)

        for elb_rule in self.elb_rules:
            elb_rule.save(elbv2_client)

        return
